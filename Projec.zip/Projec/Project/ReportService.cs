using System;
using System.Linq;

namespace ConsoleApp1
{
    public class ReportService : IReportService
    {
        private readonly IVisitManager visitManager;
        private readonly INotificationService notificationService;
        private readonly ILogger logger;

        public ReportService(IVisitManager visitManager, INotificationService notificationService, ILogger logger)
        {
            this.visitManager = visitManager;
            this.notificationService = notificationService;
            this.logger = logger;
        }

        public void GenerateIndividualVisitSummary(int visitId)
        {
            try
            {
                var visit = visitManager.GetVisitById(visitId);
                if (visit == null)
                {
                    notificationService.ShowError("Visit not found!");
                    return;
                }

                Console.WriteLine("\n=== INDIVIDUAL VISIT SUMMARY ===");
                Console.WriteLine(visit.GetVisitSummary());
                
                logger.LogActivity("Individual Visit Report", "Success", $"Visit ID: {visitId}");
            }
            catch (Exception ex)
            {
                logger.LogError("Failed to generate individual visit summary", ex);
                notificationService.ShowError($"Error generating report: {ex.Message}");
            }
        }

        public void GenerateVisitCountByType()
        {
            try
            {
                var visits = visitManager.GetAllVisits();
                var typeGroups = visits.GroupBy(v => v.VisitType)
                                      .OrderByDescending(g => g.Count());

                Console.WriteLine("\n=== VISIT COUNT BY TYPE ===");
                foreach (var group in typeGroups)
                {
                    decimal totalFees = group.Sum(v => v.Fee);
                    Console.WriteLine($"{group.Key}: {group.Count()} visits (Total Revenue: ${totalFees:F2})");
                }

                Console.WriteLine($"\nTotal Visits: {visits.Count()}");
                Console.WriteLine($"Total Revenue: ${visits.Sum(v => v.Fee):F2}");
                
                logger.LogActivity("Visit Count by Type Report", "Success", "Report generated");
            }
            catch (Exception ex)
            {
                logger.LogError("Failed to generate visit count by type report", ex);
                notificationService.ShowError($"Error generating report: {ex.Message}");
            }
        }

        public void GenerateWeeklyVisitSummary(DateTime weekStart)
        {
            try
            {
                DateTime weekEnd = weekStart.AddDays(7);
                var weeklyVisits = visitManager.FilterVisits(v => v.VisitDate >= weekStart && v.VisitDate < weekEnd)
                                              .OrderBy(v => v.VisitDate)
                                              .ToList();

                Console.WriteLine($"\n=== WEEKLY VISIT SUMMARY ({weekStart:dd/MM/yyyy} - {weekEnd.AddDays(-1):dd/MM/yyyy}) ===");
                Console.WriteLine($"Total visits this week: {weeklyVisits.Count}");
                Console.WriteLine($"Total revenue this week: ${weeklyVisits.Sum(v => v.Fee):F2}");

                if (weeklyVisits.Any())
                {
                    var dailyGroups = weeklyVisits.GroupBy(v => v.VisitDate.Date)
                                                 .OrderBy(g => g.Key);

                    Console.WriteLine("\nDaily breakdown:");
                    foreach (var day in dailyGroups)
                    {
                        Console.WriteLine($"{day.Key:dd/MM/yyyy}: {day.Count()} visits (${day.Sum(v => v.Fee):F2})");
                    }
                }
                
                logger.LogActivity("Weekly Visit Report", "Success", $"Week starting: {weekStart:dd/MM/yyyy}");
            }
            catch (Exception ex)
            {
                logger.LogError("Failed to generate weekly visit summary", ex);
                notificationService.ShowError($"Error generating report: {ex.Message}");
            }
        }

        public void GenerateMonthlyStatistics(int month, int year)
        {
            try
            {
                var monthStart = new DateTime(year, month, 1);
                var monthEnd = monthStart.AddMonths(1);
                var monthlyVisits = visitManager.FilterVisits(v => v.VisitDate >= monthStart && v.VisitDate < monthEnd)
                                                .ToList();

                Console.WriteLine($"\n=== MONTHLY STATISTICS ({monthStart:MM/yyyy}) ===");
                Console.WriteLine($"Total visits: {monthlyVisits.Count}");
                Console.WriteLine($"Total revenue: ${monthlyVisits.Sum(v => v.Fee):F2}");

                if (monthlyVisits.Any())
                {
                    var typeStats = monthlyVisits.GroupBy(v => v.VisitType)
                                                .OrderByDescending(g => g.Count());

                    Console.WriteLine("\nVisits by type:");
                    foreach (var group in typeStats)
                    {
                        decimal typeRevenue = group.Sum(v => v.Fee);
                        Console.WriteLine($"  {group.Key}: {group.Count()} visits (${typeRevenue:F2})");
                    }

                    var doctorStats = monthlyVisits.Where(v => !string.IsNullOrEmpty(v.DoctorName))
                                                  .GroupBy(v => v.DoctorName)
                                                  .OrderByDescending(g => g.Count());

                    if (doctorStats.Any())
                    {
                        Console.WriteLine("\nVisits by doctor:");
                        foreach (var group in doctorStats)
                        {
                            decimal doctorRevenue = group.Sum(v => v.Fee);
                            Console.WriteLine($"  {group.Key}: {group.Count()} visits (${doctorRevenue:F2})");
                        }
                    }
                }
                
                logger.LogActivity("Monthly Statistics Report", "Success", $"Month: {month:D2}/{year}");
            }
            catch (Exception ex)
            {
                logger.LogError("Failed to generate monthly statistics", ex);
                notificationService.ShowError($"Error generating report: {ex.Message}");
            }
        }

        public void GenerateRevenueReport()
        {
            try
            {
                var visits = visitManager.GetAllVisits();
                var totalRevenue = visits.Sum(v => v.Fee);
                var averageFee = visits.Any() ? visits.Average(v => v.Fee) : 0;

                Console.WriteLine("\n=== REVENUE REPORT ===");
                Console.WriteLine($"Total Revenue: ${totalRevenue:F2}");
                Console.WriteLine($"Average Fee per Visit: ${averageFee:F2}");
                Console.WriteLine($"Total Visits: {visits.Count()}");

                var revenueByType = visits.GroupBy(v => v.VisitType)
                                         .Select(g => new { Type = g.Key, Revenue = g.Sum(v => v.Fee) })
                                         .OrderByDescending(x => x.Revenue);

                Console.WriteLine("\nRevenue by Visit Type:");
                foreach (var item in revenueByType)
                {
                    Console.WriteLine($"  {item.Type}: ${item.Revenue:F2}");
                }
                
                logger.LogActivity("Revenue Report", "Success", "Report generated");
            }
            catch (Exception ex)
            {
                logger.LogError("Failed to generate revenue report", ex);
                notificationService.ShowError($"Error generating report: {ex.Message}");
            }
        }
    }
}
