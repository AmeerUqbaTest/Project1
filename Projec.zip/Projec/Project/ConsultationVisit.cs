using System;

namespace ConsoleApp1
{
    public class ConsultationVisit : VisitBase
    {
        public override string VisitType => "Consultation";

        public ConsultationVisit(int visitId, string patientName, DateTime visitDate, string description, string doctorName, int durationInMinutes = 30)
            : base(visitId, patientName, visitDate, description, doctorName, durationInMinutes)
        {
        }

        public override decimal CalculateFee()
        {
            decimal baseRate = 500;
            return (DurationInMinutes / 60.0m) * baseRate;
        }

        public override bool ValidateVisit()
        {
            return base.ValidateVisit() && !string.IsNullOrWhiteSpace(DoctorName);
        }
    }
}
