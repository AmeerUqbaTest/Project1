using System;

namespace ConsoleApp1
{
    public class RoutineCheckUpVisit : VisitBase
    {
        public override string VisitType => "Routine Check-up";

        public RoutineCheckUpVisit(int visitId, string patientName, DateTime visitDate, string description, string doctorName, int durationInMinutes = 45)
            : base(visitId, patientName, visitDate, description, doctorName, durationInMinutes)
        {
        }

        public override decimal CalculateFee()
        {
            decimal baseRate = 400;
            return (DurationInMinutes / 60.0m) * baseRate;
        }

        public override bool ValidateVisit()
        {
            return base.ValidateVisit();
        }
    }
}
