namespace ConsoleApp1
{
    public class UpdateVisitCommand : ICommand
    {
        private readonly IVisitRepository repository;
        private readonly IVisit oldVisit;
        private readonly IVisit newVisit;

        public UpdateVisitCommand(IVisitRepository repository, IVisit oldVisit, IVisit newVisit)
        {
            this.repository = repository;
            this.oldVisit = oldVisit;
            this.newVisit = newVisit;
        }

        public void Execute()
        {
            repository.UpdateVisit(newVisit);
        }

        public void Undo()
        {
            repository.UpdateVisit(oldVisit);
        }
    }
}
