using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    public interface IVisitRepository
    {
        void SaveVisits(IEnumerable<IVisit> visits);
        IEnumerable<IVisit> LoadVisits();
        void AddVisit(IVisit visit);
        void UpdateVisit(IVisit visit);
        void DeleteVisit(int visitId);
        IVisit? GetVisitById(int visitId);
        IEnumerable<IVisit> GetAllVisits();
    }
}
