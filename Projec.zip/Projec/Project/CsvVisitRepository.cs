using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public class CsvVisitRepository : IVisitRepository
    {
        private readonly string dataFileName;
        private readonly ILogger logger;
        private List<IVisit> visits;

        public CsvVisitRepository(ILogger logger)
        {
            this.logger = logger;
            visits = new List<IVisit>();
            dataFileName = Path.Combine(Directory.GetCurrentDirectory(), "patient_visits.csv");
        }

        public void SaveVisits(IEnumerable<IVisit> visits)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(dataFileName))
                {
                    foreach (IVisit visit in visits)
                    {
                        writer.WriteLine(ToCsvString(visit));
                    }
                }
                logger.LogInfo($"Saved {visits.Count()} visits to file");
            }
            catch (Exception ex)
            {
                logger.LogError($"Error saving visits to file", ex);
                throw;
            }
        }

        public IEnumerable<IVisit> LoadVisits()
        {
            visits.Clear();
            
            try
            {
                if (File.Exists(dataFileName))
                {
                    string[] lines = File.ReadAllLines(dataFileName);
                    foreach (string line in lines)
                    {
                        if (!string.IsNullOrWhiteSpace(line))
                        {
                            try
                            {
                                IVisit visit = FromCsvString(line);
                                visits.Add(visit);
                            }
                            catch (Exception ex)
                            {
                                logger.LogError($"Error parsing line: {line}", ex);
                            }
                        }
                    }
                    logger.LogInfo($"Loaded {visits.Count} visits from file");
                }
                else
                {
                    logger.LogInfo("No existing data file found. Starting with empty repository");
                }
            }
            catch (Exception ex)
            {
                logger.LogError("Error loading visits from file", ex);
            }

            return visits.ToList();
        }

        public void AddVisit(IVisit visit)
        {
            visits.Add(visit);
            SaveVisits(visits);
        }

        public void UpdateVisit(IVisit visit)
        {
            var existingVisit = visits.FirstOrDefault(v => v.VisitId == visit.VisitId);
            if (existingVisit != null)
            {
                int index = visits.IndexOf(existingVisit);
                visits[index] = visit;
                SaveVisits(visits);
            }
        }

        public void DeleteVisit(int visitId)
        {
            visits.RemoveAll(v => v.VisitId == visitId);
            SaveVisits(visits);
        }

        public IVisit? GetVisitById(int visitId)
        {
            return visits.FirstOrDefault(v => v.VisitId == visitId);
        }

        public IEnumerable<IVisit> GetAllVisits()
        {
            return visits.ToList();
        }

        private string ToCsvString(IVisit visit)
        {
            var data = visit.ToData();
            return $"{data["VisitId"]},{EscapeCsv(data["PatientName"]?.ToString() ?? "")},{((DateTime)data["VisitDate"]):yyyy-MM-dd},{EscapeCsv(data["VisitType"]?.ToString() ?? "")},{EscapeCsv(data["Description"]?.ToString() ?? "")},{EscapeCsv(data["DoctorName"]?.ToString() ?? "")},{data["DurationInMinutes"]},{data["Fee"]:F2}";
        }

        private IVisit FromCsvString(string csvLine)
        {
            var parts = ParseCsvLine(csvLine);
            if (parts.Length >= 6)
            {
                int visitId = int.Parse(parts[0]);
                string patientName = parts[1];
                DateTime visitDate = DateTime.Parse(parts[2]);
                string visitType = parts[3];
                string description = parts[4];
                string doctorName = parts[5];
                int durationInMinutes = parts.Length > 6 && int.TryParse(parts[6], out int duration) ? duration : 30;

                return CreateVisitByType(visitId, patientName, visitDate, visitType, description, doctorName, durationInMinutes);
            }
            throw new ArgumentException("Invalid CSV format");
        }

        private IVisit CreateVisitByType(int visitId, string patientName, DateTime visitDate, string visitType, string description, string doctorName, int durationInMinutes)
        {
            return visitType switch
            {
                "Consultation" => new ConsultationVisit(visitId, patientName, visitDate, description, doctorName, durationInMinutes),
                "Follow-up" => new FollowUpVisit(visitId, patientName, visitDate, description, doctorName, durationInMinutes),
                "Emergency" => new EmergencyVisit(visitId, patientName, visitDate, description, doctorName, durationInMinutes),
                "Routine Check-up" => new RoutineCheckUpVisit(visitId, patientName, visitDate, description, doctorName, durationInMinutes),
                _ => new ConsultationVisit(visitId, patientName, visitDate, description, doctorName, durationInMinutes)
            };
        }

        private string EscapeCsv(string field)
        {
            if (field.Contains(',') || field.Contains('"') || field.Contains('\n'))
            {
                return '"' + field.Replace("\"", "\"\"") + '"';
            }
            return field;
        }

        private string[] ParseCsvLine(string line)
        {
            var result = new List<string>();
            var current = new StringBuilder();
            bool inQuotes = false;

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"')
                {
                    if (inQuotes && i + 1 < line.Length && line[i + 1] == '"')
                    {
                        current.Append('"');
                        i++;
                    }
                    else
                    {
                        inQuotes = !inQuotes;
                    }
                }
                else if (c == ',' && !inQuotes)
                {
                    result.Add(current.ToString());
                    current.Clear();
                }
                else
                {
                    current.Append(c);
                }
            }
            result.Add(current.ToString());
            return result.ToArray();
        }
    }
}
