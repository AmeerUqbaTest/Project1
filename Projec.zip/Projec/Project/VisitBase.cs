using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    public abstract class VisitBase : IVisit
    {
        public int VisitId { get; set; }
        public string PatientName { get; set; }
        public DateTime VisitDate { get; set; }
        public abstract string VisitType { get; }
        public string Description { get; set; }
        public string DoctorName { get; set; }
        public int DurationInMinutes { get; set; }
        public decimal Fee => CalculateFee();

        protected VisitBase(int visitId, string patientName, DateTime visitDate, string description, string doctorName, int durationInMinutes)
        {
            VisitId = visitId;
            PatientName = patientName ?? "";
            VisitDate = visitDate;
            Description = description ?? "";
            DoctorName = doctorName ?? "";
            DurationInMinutes = durationInMinutes;
        }

        public abstract decimal CalculateFee();

        public virtual bool ValidateVisit()
        {
            return !string.IsNullOrWhiteSpace(PatientName) && 
                   DurationInMinutes > 0 && 
                   VisitDate != default(DateTime);
        }

        public virtual string GetVisitSummary()
        {
            return $"ID: {VisitId}, Name: {PatientName}, Date: {VisitDate:dd/MM/yyyy}, Type: {VisitType}, Doctor: {DoctorName}, Description: {Description}, Duration: {DurationInMinutes}min, Fee: ${Fee:F2}";
        }

        public virtual Dictionary<string, object> ToData()
        {
            return new Dictionary<string, object>
            {
                ["VisitId"] = VisitId,
                ["PatientName"] = PatientName,
                ["VisitDate"] = VisitDate,
                ["VisitType"] = VisitType,
                ["Description"] = Description,
                ["DoctorName"] = DoctorName,
                ["DurationInMinutes"] = DurationInMinutes,
                ["Fee"] = Fee
            };
        }

        protected virtual decimal GetBaseRate()
        {
            return 100;
        }
    }
}
