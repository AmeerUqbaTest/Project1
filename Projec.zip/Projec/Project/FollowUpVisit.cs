using System;

namespace ConsoleApp1
{
    public class FollowUpVisit : VisitBase
    {
        public override string VisitType => "Follow-up";

        public FollowUpVisit(int visitId, string patientName, DateTime visitDate, string description, string doctorName, int durationInMinutes = 20)
            : base(visitId, patientName, visitDate, description, doctorName, durationInMinutes)
        {
        }

        public override decimal CalculateFee()
        {
            decimal baseRate = 300;
            return (DurationInMinutes / 60.0m) * baseRate;
        }

        public override bool ValidateVisit()
        {
            return base.ValidateVisit();
        }
    }
}
