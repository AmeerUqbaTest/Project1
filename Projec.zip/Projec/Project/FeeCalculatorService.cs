using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace ConsoleApp1
{
    public class FeeConfiguration
    {
        public decimal Consultation { get; set; }
        public decimal FollowUp { get; set; }
        public decimal Emergency { get; set; }
        public decimal RoutineCheckUp { get; set; }
    }

    public class FeeCalculatorService
    {
        private FeeConfiguration? feeConfig;
        private const string feeConfigFileName = "..\\..\\..\\fees.json";

        public FeeCalculatorService()
        {
            LoadFeeConfiguration();
        }

        private void LoadFeeConfiguration()
        {
            try
            {
                if (File.Exists(feeConfigFileName))
                {
                    string jsonContent = File.ReadAllText(feeConfigFileName);
                    feeConfig = JsonSerializer.Deserialize<FeeConfiguration>(jsonContent) ?? CreateDefaultConfiguration();
                }
                else
                {
                    feeConfig = CreateDefaultConfiguration();
                    SaveFeeConfiguration();
                }
            }
            catch (Exception)
            {
                feeConfig = CreateDefaultConfiguration();
            }
        }

        private FeeConfiguration CreateDefaultConfiguration()
        {
            return new FeeConfiguration
            {
                Consultation = 500,
                FollowUp = 300,
                Emergency = 1000,
                RoutineCheckUp = 400
            };
        }

        private void SaveFeeConfiguration()
        {
            try
            {
                string jsonContent = JsonSerializer.Serialize(feeConfig, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(feeConfigFileName, jsonContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving fee configuration: {ex.Message}");
            }
        }

        public decimal CalculateFee(string visitType, int durationInMinutes)
        {
            if (feeConfig == null)
            {
                feeConfig = CreateDefaultConfiguration();
            }

            decimal baseRate = visitType switch
            {
                "Consultation" => feeConfig.Consultation,
                "Follow-up" => feeConfig.FollowUp,
                "Emergency" => feeConfig.Emergency,
                "Routine Check-up" => feeConfig.RoutineCheckUp,
                _ => feeConfig.Consultation
            };

            decimal hourlyRate = baseRate;
            return (durationInMinutes / 60.0m) * hourlyRate;
        }
    }
}
