using System;
using System.IO;

namespace ConsoleApp1
{
    public class FileLogger : ILogger
    {
        private readonly string logFileName;

        public FileLogger()
        {
            logFileName = Path.Combine(Directory.GetCurrentDirectory(), "activity_log.txt");
        }

        public void LogActivity(string action, string outcome, string details = "")
        {
            try
            {
                string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {action} - {outcome}";
                if (!string.IsNullOrEmpty(details))
                {
                    logEntry += $" - {details}";
                }

                File.AppendAllText(logFileName, logEntry + Environment.NewLine);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to log activity: {ex.Message}");
            }
        }

        public void LogError(string message, Exception? exception = null)
        {
            string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] ERROR - {message}";
            if (exception != null)
            {
                logEntry += $" - Exception: {exception.Message}";
            }
            
            try
            {
                File.AppendAllText(logFileName, logEntry + Environment.NewLine);
            }
            catch
            {
                Console.WriteLine($"Failed to log error: {message}");
            }
        }

        public void LogInfo(string message)
        {
            try
            {
                string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] INFO - {message}";
                File.AppendAllText(logFileName, logEntry + Environment.NewLine);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to log info: {ex.Message}");
            }
        }
    }
}
