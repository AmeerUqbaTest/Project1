namespace ConsoleApp1
{
    public interface INotificationService
    {
        void ShowSuccess(string message);
        void ShowError(string message);
        void ShowWarning(string message);
        void ShowInfo(string message);
        bool AskForConfirmation(string message);
        bool AskForOverride(string conflictMessage);
    }
}
