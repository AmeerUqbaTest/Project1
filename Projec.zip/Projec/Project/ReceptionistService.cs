using System;
using System.Globalization;
using System.Linq;

namespace ConsoleApp1
{
    public class ReceptionistService : IUserService
    {
        private readonly IVisitManager visitManager;
        private readonly IReportService reportService;
        private readonly INotificationService notificationService;
        private readonly ILogger logger;

        public UserRole Role => UserRole.Receptionist;

        public ReceptionistService(IVisitManager visitManager, IReportService reportService, INotificationService notificationService, ILogger logger)
        {
            this.visitManager = visitManager;
            this.reportService = reportService;
            this.notificationService = notificationService;
            this.logger = logger;
        }

        public void AddNewVisit()
        {
            Console.WriteLine("=== ADD NEW PATIENT VISIT ===");

            try
            {
                Console.Write("Enter patient name: ");
                string patientName = Console.ReadLine() ?? "";
                if (string.IsNullOrWhiteSpace(patientName))
                {
                    notificationService.ShowError("Patient name cannot be empty!");
                    return;
                }

                Console.Write("Enter visit date (DD/MM/YYYY) or press Enter for today: ");
                string dateInput = Console.ReadLine() ?? "";
                DateTime visitDate;
                if (string.IsNullOrWhiteSpace(dateInput))
                {
                    visitDate = DateTime.Today;
                }
                else if (!DateTime.TryParseExact(dateInput, "dd/MM/yyyy", null, DateTimeStyles.None, out visitDate))
                {
                    notificationService.ShowError("Invalid date format! Please use DD/MM/YYYY");
                    return;
                }

                if (visitManager.HasTimeSlotConflict(patientName, visitDate))
                {
                    if (!notificationService.AskForOverride("This patient has another visit within 30 minutes."))
                    {
                        notificationService.ShowInfo("Operation cancelled due to time slot conflict.");
                        return;
                    }
                }

                Console.WriteLine("Select visit type:");
                Console.WriteLine("1. Consultation");
                Console.WriteLine("2. Follow-up");
                Console.WriteLine("3. Emergency");
                Console.WriteLine("4. Routine Check-up");
                Console.Write("Enter choice (1-4): ");
                string typeChoice = Console.ReadLine() ?? "";

                Console.Write("Enter description/notes: ");
                string description = Console.ReadLine() ?? "";

                Console.Write("Enter doctor name (optional): ");
                string doctorName = Console.ReadLine() ?? "";

                Console.Write("Enter visit duration in minutes (default varies by type): ");
                string durationInput = Console.ReadLine() ?? "";

                IVisit newVisit = CreateVisitByType(typeChoice, 0, patientName, visitDate, description, doctorName, durationInput);

                Console.WriteLine($"Calculated fee: ${newVisit.Fee:F2}");

                visitManager.AddVisit(newVisit);
                notificationService.ShowSuccess($"Patient visit added successfully! ID: {newVisit.VisitId}");
            }
            catch (Exception ex)
            {
                notificationService.ShowError($"Error adding patient visit: {ex.Message}");
                logger.LogError("Failed to add visit", ex);
            }
        }

        public void SearchVisits()
        {
            Console.WriteLine("=== SEARCH PATIENT VISITS ===");
            Console.WriteLine("1. Search by Patient Name");
            Console.WriteLine("2. Search by Doctor Name");
            Console.WriteLine("3. Search by Visit Type");
            Console.WriteLine("4. Search by Date");
            Console.WriteLine("5. View All Visits");
            Console.Write("Choose search option (1-5): ");

            string choice = Console.ReadLine() ?? "";
            
            try
            {
                var results = choice switch
                {
                    "1" => SearchByPatientName(),
                    "2" => SearchByDoctorName(),
                    "3" => SearchByVisitType(),
                    "4" => SearchByDate(),
                    "5" => visitManager.GetAllVisits(),
                    _ => throw new ArgumentException("Invalid choice")
                };

                DisplaySearchResults(results);
            }
            catch (Exception ex)
            {
                notificationService.ShowError($"Error during search: {ex.Message}");
                logger.LogError("Search failed", ex);
            }
        }

        public void GenerateReports()
        {
            Console.WriteLine("=== REPORTS AND STATISTICS ===");
            Console.WriteLine("1. Individual Visit Summary");
            Console.WriteLine("2. Visit Count by Type");
            Console.WriteLine("3. Weekly Visit Summary");
            Console.WriteLine("4. Monthly Statistics");
            Console.WriteLine("5. Revenue Report");
            Console.Write("Choose report option (1-5): ");

            string choice = Console.ReadLine() ?? "";

            try
            {
                switch (choice)
                {
                    case "1":
                        GenerateIndividualReport();
                        break;
                    case "2":
                        reportService.GenerateVisitCountByType();
                        break;
                    case "3":
                        GenerateWeeklyReport();
                        break;
                    case "4":
                        GenerateMonthlyReport();
                        break;
                    case "5":
                        reportService.GenerateRevenueReport();
                        break;
                    default:
                        notificationService.ShowError("Invalid choice!");
                        break;
                }
            }
            catch (Exception ex)
            {
                notificationService.ShowError($"Error generating report: {ex.Message}");
                logger.LogError("Report generation failed", ex);
            }
        }

        public void SaveData()
        {
            try
            {
                var visits = visitManager.GetAllVisits();
                notificationService.ShowSuccess($"Data saved successfully! Total visits: {visits.Count()}");
                logger.LogActivity("Save Data", "Success", $"Total visits: {visits.Count()}");
            }
            catch (Exception ex)
            {
                notificationService.ShowError($"Error saving data: {ex.Message}");
                logger.LogError("Failed to save data", ex);
            }
        }

        private IVisit CreateVisitByType(string typeChoice, int visitId, string patientName, DateTime visitDate, string description, string doctorName, string durationInput)
        {
            return typeChoice switch
            {
                "1" => CreateConsultation(visitId, patientName, visitDate, description, doctorName, durationInput),
                "2" => CreateFollowUp(visitId, patientName, visitDate, description, doctorName, durationInput),
                "3" => CreateEmergency(visitId, patientName, visitDate, description, doctorName, durationInput),
                "4" => CreateRoutineCheckUp(visitId, patientName, visitDate, description, doctorName, durationInput),
                _ => CreateConsultation(visitId, patientName, visitDate, description, doctorName, durationInput)
            };
        }

        private ConsultationVisit CreateConsultation(int visitId, string patientName, DateTime visitDate, string description, string doctorName, string durationInput)
        {
            int duration = string.IsNullOrWhiteSpace(durationInput) ? 30 : (int.TryParse(durationInput, out int d) && d > 0 ? d : 30);
            return new ConsultationVisit(visitId, patientName, visitDate, description, doctorName, duration);
        }

        private FollowUpVisit CreateFollowUp(int visitId, string patientName, DateTime visitDate, string description, string doctorName, string durationInput)
        {
            int duration = string.IsNullOrWhiteSpace(durationInput) ? 20 : (int.TryParse(durationInput, out int d) && d > 0 ? d : 20);
            return new FollowUpVisit(visitId, patientName, visitDate, description, doctorName, duration);
        }

        private EmergencyVisit CreateEmergency(int visitId, string patientName, DateTime visitDate, string description, string doctorName, string durationInput)
        {
            int duration = string.IsNullOrWhiteSpace(durationInput) ? 60 : (int.TryParse(durationInput, out int d) && d > 0 ? d : 60);
            return new EmergencyVisit(visitId, patientName, visitDate, description, doctorName, duration);
        }

        private RoutineCheckUpVisit CreateRoutineCheckUp(int visitId, string patientName, DateTime visitDate, string description, string doctorName, string durationInput)
        {
            int duration = string.IsNullOrWhiteSpace(durationInput) ? 45 : (int.TryParse(durationInput, out int d) && d > 0 ? d : 45);
            return new RoutineCheckUpVisit(visitId, patientName, visitDate, description, doctorName, duration);
        }

        private System.Collections.Generic.IEnumerable<IVisit> SearchByPatientName()
        {
            Console.Write("Enter patient name (partial match): ");
            string searchTerm = Console.ReadLine()?.ToLower() ?? "";
            return visitManager.SearchVisits("patient", searchTerm);
        }

        private System.Collections.Generic.IEnumerable<IVisit> SearchByDoctorName()
        {
            Console.Write("Enter doctor name (partial match): ");
            string searchTerm = Console.ReadLine()?.ToLower() ?? "";
            return visitManager.SearchVisits("doctor", searchTerm);
        }

        private System.Collections.Generic.IEnumerable<IVisit> SearchByVisitType()
        {
            Console.WriteLine("Select visit type:");
            Console.WriteLine("1. Consultation");
            Console.WriteLine("2. Follow-up");
            Console.WriteLine("3. Emergency");
            Console.WriteLine("4. Routine Check-up");
            Console.Write("Enter choice (1-4): ");
            string typeChoice = Console.ReadLine() ?? "";

            string visitType = typeChoice switch
            {
                "1" => "Consultation",
                "2" => "Follow-up",
                "3" => "Emergency",
                "4" => "Routine Check-up",
                _ => ""
            };

            return visitManager.SearchVisits("type", visitType);
        }

        private System.Collections.Generic.IEnumerable<IVisit> SearchByDate()
        {
            Console.Write("Enter date (DD/MM/YYYY): ");
            string dateInput = Console.ReadLine() ?? "";
            if (DateTime.TryParseExact(dateInput, "dd/MM/yyyy", null, DateTimeStyles.None, out DateTime searchDate))
            {
                return visitManager.FilterVisits(v => v.VisitDate.Date == searchDate.Date);
            }
            throw new ArgumentException("Invalid date format!");
        }

        private void DisplaySearchResults(System.Collections.Generic.IEnumerable<IVisit> results)
        {
            var resultList = results.ToList();
            if (!resultList.Any())
            {
                Console.WriteLine("No visits found matching the search criteria.");
                return;
            }

            Console.WriteLine($"\nFound {resultList.Count} visit(s):");
            Console.WriteLine(new string('-', 120));

            foreach (var visit in resultList.OrderBy(v => v.VisitDate))
            {
                Console.WriteLine(visit.GetVisitSummary());
            }
        }

        private void GenerateIndividualReport()
        {
            Console.Write("Enter visit ID for summary: ");
            if (int.TryParse(Console.ReadLine(), out int visitId))
            {
                reportService.GenerateIndividualVisitSummary(visitId);
            }
            else
            {
                notificationService.ShowError("Invalid visit ID!");
            }
        }

        private void GenerateWeeklyReport()
        {
            Console.Write("Enter week start date (DD/MM/YYYY): ");
            if (DateTime.TryParseExact(Console.ReadLine(), "dd/MM/yyyy", null, DateTimeStyles.None, out DateTime weekStart))
            {
                reportService.GenerateWeeklyVisitSummary(weekStart);
            }
            else
            {
                notificationService.ShowError("Invalid date format!");
            }
        }

        private void GenerateMonthlyReport()
        {
            Console.Write("Enter month (MM/YYYY): ");
            string monthInput = Console.ReadLine() ?? "";
            if (DateTime.TryParseExact($"01/{monthInput}", "dd/MM/yyyy", null, DateTimeStyles.None, out DateTime monthDate))
            {
                reportService.GenerateMonthlyStatistics(monthDate.Month, monthDate.Year);
            }
            else
            {
                notificationService.ShowError("Invalid month format! Use MM/YYYY");
            }
        }
    }
}
