using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    public interface IUserService
    {
        void AddNewVisit();
        void SearchVisits();
        void GenerateReports();
        void SaveData();
        UserRole Role { get; }
    }
}
