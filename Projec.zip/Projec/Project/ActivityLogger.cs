using System;
using System.IO;
using System.Text.Json;

namespace ConsoleApp1
{
    public class ActivityLogger
    {
        private const string logFileName = "..\\..\\..\\activity_log.txt";

        public void LogActivity(string action, string outcome, string details = "")
        {
            try
            {
                string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {action} - {outcome}";
                if (!string.IsNullOrEmpty(details))
                {
                    logEntry += $" - {details}";
                }

                File.AppendAllText(logFileName, logEntry + Environment.NewLine);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to log activity: {ex.Message}");
            }
        }
    }
}
