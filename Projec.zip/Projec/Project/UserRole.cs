namespace ConsoleApp1
{
    public enum UserRole
    {
        Admin,
        Receptionist
    }
}
