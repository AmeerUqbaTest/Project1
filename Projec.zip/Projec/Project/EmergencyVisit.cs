using System;

namespace ConsoleApp1
{
    public class EmergencyVisit : VisitBase
    {
        public override string VisitType => "Emergency";
        public int UrgencyLevel { get; set; }

        public EmergencyVisit(int visitId, string patientName, DateTime visitDate, string description, string doctorName, int durationInMinutes = 60, int urgencyLevel = 1)
            : base(visitId, patientName, visitDate, description, doctorName, durationInMinutes)
        {
            UrgencyLevel = urgencyLevel;
        }

        public override decimal CalculateFee()
        {
            decimal baseRate = 1000;
            decimal urgencyMultiplier = UrgencyLevel switch
            {
                1 => 1.0m,
                2 => 1.5m,
                3 => 2.0m,
                _ => 1.0m
            };
            return (DurationInMinutes / 60.0m) * baseRate * urgencyMultiplier;
        }

        public override bool ValidateVisit()
        {
            return base.ValidateVisit() && UrgencyLevel >= 1 && UrgencyLevel <= 3;
        }

        public override string GetVisitSummary()
        {
            return base.GetVisitSummary() + $", Urgency: {UrgencyLevel}";
        }
    }
}
