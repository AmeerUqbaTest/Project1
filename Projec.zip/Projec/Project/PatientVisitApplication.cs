using System;
using System.IO;
using System.Linq;

namespace ConsoleApp1
{
    public class PatientVisitApplication
    {
        private readonly ILogger logger;
        private readonly INotificationService notificationService;
        private readonly IVisitRepository repository;
        private readonly IVisitManager visitManager;
        private readonly IReportService reportService;
        private readonly IAuthenticationService authService;
        private IUserService? currentUserService;

        public PatientVisitApplication()
        {
            logger = new FileLogger();
            notificationService = new ConsoleNotificationService();
            repository = new CsvVisitRepository(logger);
            visitManager = new VisitManager(repository, logger, notificationService);
            reportService = new ReportService(visitManager, notificationService, logger);
            authService = new AuthenticationService(logger, notificationService);
        }

        public void Run()
        {
            try
            {
                logger.LogActivity("Application", "Started", "Patient Visit Manager started");
                
                if (!AuthenticateUser())
                {
                    notificationService.ShowError("Authentication failed. Exiting application...");
                    logger.LogActivity("Application", "Exit", "Authentication failed");
                    return;
                }

                GenerateMockDataIfNeeded();
                
                ShowMainMenu();
                
                logger.LogActivity("Application", "Exit", "Normal application exit");
            }
            catch (Exception ex)
            {
                logger.LogError("Critical application error", ex);
                notificationService.ShowError($"A critical error occurred: {ex.Message}");
            }
        }

        private bool AuthenticateUser()
        {
            const int maxAttempts = 3;
            int attempts = 0;

            while (attempts < maxAttempts)
            {
                var authResult = authService.Authenticate();
                
                if (authResult.isAuthenticated)
                {
                    currentUserService = authResult.role switch
                    {
                        UserRole.Admin => new AdminService(visitManager, reportService, notificationService, logger),
                        UserRole.Receptionist => new ReceptionistService(visitManager, reportService, notificationService, logger),
                        _ => throw new ArgumentException($"Invalid user role: {authResult.role}")
                    };

                    notificationService.ShowSuccess($"Successfully logged in as {authResult.role}");
                    logger.LogActivity("Authentication", "Success", $"User logged in with role: {authResult.role}");
                    return true;
                }

                attempts++;
                notificationService.ShowError($"Authentication failed. Attempts remaining: {maxAttempts - attempts}");
                
                if (attempts < maxAttempts)
                {
                    notificationService.ShowInfo("Please try again...\n");
                }
            }

            notificationService.ShowError("Maximum authentication attempts exceeded.");
            return false;
        }

        private void GenerateMockDataIfNeeded()
        {
            string dataFilePath = Path.Combine(Directory.GetCurrentDirectory(), "patient_visits.csv");
            if (File.Exists(dataFilePath))
            {
                var existingVisits = visitManager.GetAllVisits();
                notificationService.ShowInfo($"Loaded {existingVisits.Count()} existing visits from file.");
                return;
            }

            notificationService.ShowInfo("No existing data file found. Generating mock data for testing...");
            
            try
            {
                GenerateMockData();
                repository.SaveVisits(visitManager.GetAllVisits());
                notificationService.ShowSuccess("Mock data generated and saved successfully!");
            }
            catch (Exception ex)
            {
                logger.LogError("Failed to generate mock data", ex);
                notificationService.ShowWarning("Failed to generate mock data. Starting with empty database.");
            }
        }

        private void GenerateMockData()
        {
            Random random = new Random();
            string[] firstNames = { "John", "Jane", "Michael", "Sarah", "David", "Emma", "James", "Lisa", "Robert", "Maria", "William", "Jennifer", "Richard", "Patricia", "Joseph", "Linda", "Thomas", "Elizabeth", "Charles", "Barbara" };
            string[] lastNames = { "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin" };
            string[] doctors = { "Dr. Smith", "Dr. Johnson", "Dr. Williams", "Dr. Brown", "Dr. Davis", "Dr. Miller", "Dr. Wilson", "Dr. Moore", "Dr. Taylor", "Dr. Anderson" };
            string[] descriptions = { "Regular checkup", "Follow-up appointment", "Urgent medical attention needed", "Routine examination", "Consultation for symptoms", "Preventive care visit", "Health screening", "Medical evaluation", "Treatment follow-up", "Annual physical exam" };

            int numberOfRecords = random.Next(50, 101);

            for (int i = 0; i < numberOfRecords; i++)
            {
                string patientName = $"{firstNames[random.Next(firstNames.Length)]} {lastNames[random.Next(lastNames.Length)]}";
                DateTime visitDate = DateTime.Today.AddDays(-random.Next(0, 365));
                string description = descriptions[random.Next(descriptions.Length)];
                string doctorName = random.Next(10) < 8 ? doctors[random.Next(doctors.Length)] : "";
                int durationInMinutes = random.Next(15, 121);

                IVisit mockVisit = random.Next(4) switch
                {
                    0 => new ConsultationVisit(0, patientName, visitDate, description, doctorName, durationInMinutes),
                    1 => new FollowUpVisit(0, patientName, visitDate, description, doctorName, durationInMinutes),
                    2 => new EmergencyVisit(0, patientName, visitDate, description, doctorName, durationInMinutes),
                    3 => new RoutineCheckUpVisit(0, patientName, visitDate, description, doctorName, durationInMinutes),
                    _ => new ConsultationVisit(0, patientName, visitDate, description, doctorName, durationInMinutes)
                };

                visitManager.AddVisit(mockVisit);
            }

            logger.LogActivity("Generate Mock Data", "Success", $"{numberOfRecords} records generated");
        }

        private void ShowMainMenu()
        {
            while (true)
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("=== PATIENT VISIT MANAGER ===");
                    if (currentUserService == null)
                {
                    notificationService.ShowError("Authentication failed. Exiting...");
                    return;
                }

                Console.WriteLine($"Logged in as: {currentUserService.Role}");
                    Console.WriteLine();

                    if (currentUserService.Role == UserRole.Admin)
                    {
                        ShowAdminMenu();
                    }
                    else
                    {
                        ShowReceptionistMenu();
                    }

                    string choice = Console.ReadLine() ?? "";
                    Console.Clear();

                    if (!ProcessMenuChoice(choice))
                    {
                        break;
                    }

                    if (!IsExitChoice(choice))
                    {
                        Console.WriteLine("\nPress any key to continue...");
                        Console.ReadKey();
                    }
                }
                catch (Exception ex)
                {
                    logger.LogError("Menu processing error", ex);
                    notificationService.ShowError($"Error: {ex.Message}");
                    Console.WriteLine("\nPress any key to continue...");
                    Console.ReadKey();
                }
            }
        }

        private void ShowAdminMenu()
        {
            Console.WriteLine("1. Add New Patient Visit");
            Console.WriteLine("2. Update Patient Visit");
            Console.WriteLine("3. Delete Patient Visit");
            Console.WriteLine("4. Search Patient Visits");
            Console.WriteLine("5. Generate Reports");
            Console.WriteLine("6. Undo Last Operation");
            Console.WriteLine("7. Redo Last Undone Operation");
            Console.WriteLine("8. Save Data");
            Console.WriteLine("9. Exit");
            Console.Write("Choose an option (1-9): ");
        }

        private void ShowReceptionistMenu()
        {
            Console.WriteLine("1. Add New Patient Visit");
            Console.WriteLine("2. Search Patient Visits");
            Console.WriteLine("3. Generate Reports");
            Console.WriteLine("4. Save Data");
            Console.WriteLine("5. Exit");
            Console.Write("Choose an option (1-5): ");
        }

        private bool ProcessMenuChoice(string choice)
        {
            try
            {
                if (currentUserService == null)
                {
                    notificationService.ShowError("Session expired. Please restart the application.");
                    return false;
                }

                if (currentUserService.Role == UserRole.Admin)
                {
                    return ProcessAdminChoice(choice);
                }
                else
                {
                    return ProcessReceptionistChoice(choice);
                }
            }
            catch (Exception ex)
            {
                logger.LogError($"Error processing menu choice: {choice}", ex);
                notificationService.ShowError($"Error processing request: {ex.Message}");
                return true;
            }
        }

        private bool ProcessAdminChoice(string choice)
        {
            if (currentUserService == null)
            {
                notificationService.ShowError("Session expired.");
                return false;
            }

            if (currentUserService is not AdminService adminService)
            {
                notificationService.ShowError("Invalid admin session.");
                return false;
            }
            
            switch (choice)
            {
                case "1":
                    currentUserService.AddNewVisit();
                    break;
                case "2":
                    adminService.UpdateVisit();
                    break;
                case "3":
                    adminService.DeleteVisit();
                    break;
                case "4":
                    currentUserService.SearchVisits();
                    break;
                case "5":
                    currentUserService.GenerateReports();
                    break;
                case "6":
                    adminService.UndoLastOperation();
                    break;
                case "7":
                    adminService.RedoLastOperation();
                    break;
                case "8":
                    currentUserService.SaveData();
                    break;
                case "9":
                    currentUserService.SaveData();
                    return false;
                default:
                    notificationService.ShowError("Invalid choice. Please try again.");
                    break;
            }
            return true;
        }

        private bool ProcessReceptionistChoice(string choice)
        {
            if (currentUserService == null)
            {
                notificationService.ShowError("Session expired.");
                return false;
            }

            switch (choice)
            {
                case "1":
                    currentUserService.AddNewVisit();
                    break;
                case "2":
                    currentUserService.SearchVisits();
                    break;
                case "3":
                    currentUserService.GenerateReports();
                    break;
                case "4":
                    currentUserService.SaveData();
                    break;
                case "5":
                    currentUserService.SaveData();
                    return false;
                default:
                    notificationService.ShowError("Invalid choice. Please try again.");
                    break;
            }
            return true;
        }

        private bool IsExitChoice(string choice)
        {
            if (currentUserService == null) return true;
            
            return (currentUserService.Role == UserRole.Admin && choice == "9") ||
                   (currentUserService.Role == UserRole.Receptionist && choice == "5");
        }
    }
}
