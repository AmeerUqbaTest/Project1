using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    public interface IVisitManager
    {
        void AddVisit(IVisit visit);
        void UpdateVisit(IVisit visit);
        void DeleteVisit(int visitId);
        IVisit? GetVisitById(int visitId);
        IEnumerable<IVisit> GetAllVisits();
        IEnumerable<IVisit> SearchVisits(string searchCriteria, string searchValue);
        IEnumerable<IVisit> FilterVisits(Func<IVisit, bool> filter);
        bool HasTimeSlotConflict(string patientName, DateTime visitDate);
        void UndoLastOperation();
        void RedoLastOperation();
        bool CanUndo { get; }
        bool CanRedo { get; }
    }
}
