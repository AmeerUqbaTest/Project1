﻿﻿using System;

namespace ConsoleApp1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var application = new PatientVisitApplication();
            application.Run();
        }
    }
}
