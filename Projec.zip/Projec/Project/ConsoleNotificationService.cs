using System;

namespace ConsoleApp1
{
    public class ConsoleNotificationService : INotificationService
    {
        public void ShowSuccess(string message)
        {
            Console.WriteLine($"*** {message} ***");
        }

        public void ShowError(string message)
        {
            Console.WriteLine($"*** {message} ***");
        }

        public void ShowWarning(string message)
        {
            Console.WriteLine($"*** {message} ***");
        }

        public void ShowInfo(string message)
        {
            Console.WriteLine($"*** {message} ***");
        }

        public bool AskForConfirmation(string message)
        {
            Console.Write($"{message} (y/n): ");
            string response = Console.ReadLine()?.ToLower() ?? "";
            return response == "y" || response == "yes";
        }

        public bool AskForOverride(string conflictMessage)
        {
            ShowWarning(conflictMessage);
            return AskForConfirmation("Do you want to proceed anyway?");
        }
    }
}
