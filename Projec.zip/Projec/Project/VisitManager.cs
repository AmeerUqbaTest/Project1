using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
    public class VisitManager : IVisitManager
    {
        private readonly IVisitRepository repository;
        private readonly ILogger logger;
        private readonly INotificationService notificationService;
        private readonly Stack<ICommand> undoStack;
        private readonly Stack<ICommand> redoStack;
        private const int maxUndoOperations = 10;
        private int nextVisitId;

        public bool CanUndo => undoStack.Count > 0;
        public bool CanRedo => redoStack.Count > 0;

        public VisitManager(IVisitRepository repository, ILogger logger, INotificationService notificationService)
        {
            this.repository = repository;
            this.logger = logger;
            this.notificationService = notificationService;
            undoStack = new Stack<ICommand>();
            redoStack = new Stack<ICommand>();
            
            var visits = repository.LoadVisits();
            nextVisitId = visits.Any() ? visits.Max(v => v.VisitId) + 1 : 1;
        }

        public void AddVisit(IVisit visit)
        {
            try
            {
                if (visit.VisitId == 0)
                {
                    visit.VisitId = nextVisitId++;
                }

                if (!visit.ValidateVisit())
                {
                    throw new ArgumentException("Visit validation failed");
                }

                var command = new AddVisitCommand(repository, visit);
                ExecuteCommand(command);
                
                logger.LogActivity("Add Visit", "Success", $"ID: {visit.VisitId}, Patient: {visit.PatientName}");
            }
            catch (Exception ex)
            {
                logger.LogError("Failed to add visit", ex);
                throw;
            }
        }

        public void UpdateVisit(IVisit visit)
        {
            try
            {
                if (!visit.ValidateVisit())
                {
                    throw new ArgumentException("Visit validation failed");
                }

                var oldVisit = repository.GetVisitById(visit.VisitId);
                if (oldVisit == null)
                {
                    throw new ArgumentException("Visit not found");
                }

                var command = new UpdateVisitCommand(repository, oldVisit, visit);
                ExecuteCommand(command);
                
                logger.LogActivity("Update Visit", "Success", $"ID: {visit.VisitId}");
            }
            catch (Exception ex)
            {
                logger.LogError("Failed to update visit", ex);
                throw;
            }
        }

        public void DeleteVisit(int visitId)
        {
            try
            {
                var visit = repository.GetVisitById(visitId);
                if (visit == null)
                {
                    throw new ArgumentException("Visit not found");
                }

                var command = new DeleteVisitCommand(repository, visit);
                ExecuteCommand(command);
                
                logger.LogActivity("Delete Visit", "Success", $"ID: {visitId}");
            }
            catch (Exception ex)
            {
                logger.LogError("Failed to delete visit", ex);
                throw;
            }
        }

        public IVisit? GetVisitById(int visitId)
        {
            return repository.GetVisitById(visitId);
        }

        public IEnumerable<IVisit> GetAllVisits()
        {
            return repository.GetAllVisits();
        }

        public IEnumerable<IVisit> SearchVisits(string searchCriteria, string searchValue)
        {
            var visits = repository.GetAllVisits();
            
            return searchCriteria.ToLower() switch
            {
                "patient" => visits.Where(v => v.PatientName.Contains(searchValue, StringComparison.OrdinalIgnoreCase)),
                "doctor" => visits.Where(v => v.DoctorName.Contains(searchValue, StringComparison.OrdinalIgnoreCase)),
                "type" => visits.Where(v => v.VisitType.Contains(searchValue, StringComparison.OrdinalIgnoreCase)),
                _ => visits
            };
        }

        public IEnumerable<IVisit> FilterVisits(Func<IVisit, bool> filter)
        {
            return repository.GetAllVisits().Where(filter);
        }

        public bool HasTimeSlotConflict(string patientName, DateTime visitDate)
        {
            var visits = repository.GetAllVisits();
            var conflictWindow = TimeSpan.FromMinutes(30);
            
            return visits.Any(v => 
                v.PatientName.Equals(patientName, StringComparison.OrdinalIgnoreCase) &&
                Math.Abs((v.VisitDate - visitDate).TotalMinutes) <= conflictWindow.TotalMinutes);
        }

        public void UndoLastOperation()
        {
            if (!CanUndo)
            {
                throw new InvalidOperationException("No operations to undo");
            }

            var command = undoStack.Pop();
            command.Undo();
            redoStack.Push(command);
            
            logger.LogActivity("Undo", "Success", "Operation undone");
        }

        public void RedoLastOperation()
        {
            if (!CanRedo)
            {
                throw new InvalidOperationException("No operations to redo");
            }

            var command = redoStack.Pop();
            command.Execute();
            undoStack.Push(command);
            
            logger.LogActivity("Redo", "Success", "Operation redone");
        }

        private void ExecuteCommand(ICommand command)
        {
            command.Execute();
            undoStack.Push(command);

            if (undoStack.Count > maxUndoOperations)
            {
                var commands = undoStack.ToArray();
                undoStack.Clear();
                for (int i = commands.Length - maxUndoOperations; i < commands.Length; i++)
                {
                    undoStack.Push(commands[i]);
                }
            }

            redoStack.Clear();
        }
    }
}
