using System;

namespace ConsoleApp1
{
    public interface IAuthenticationService
    {
        (bool isAuthenticated, UserRole role) Authenticate();
    }

    public class AuthenticationService : IAuthenticationService
    {
        private readonly ILogger logger;
        private readonly INotificationService notificationService;

        public AuthenticationService(ILogger logger, INotificationService notificationService)
        {
            this.logger = logger;
            this.notificationService = notificationService;
        }

        public (bool isAuthenticated, UserRole role) Authenticate()
        {
            Console.Clear();
            Console.WriteLine("=== PATIENT VISIT MANAGER LOGIN ===");
            Console.WriteLine("Select your role:");
            Console.WriteLine("1. Administrator");
            Console.WriteLine("2. Receptionist");
            Console.Write("Enter your choice (1-2): ");

            string choice = Console.ReadLine() ?? "";
            
            switch (choice)
            {
                case "1":
                    if (AuthenticateAdmin())
                    {
                        logger.LogActivity("Authentication", "Success", "Admin login successful");
                        return (true, UserRole.Admin);
                    }
                    break;
                case "2":
                    if (AuthenticateReceptionist())
                    {
                        logger.LogActivity("Authentication", "Success", "Receptionist login successful");
                        return (true, UserRole.Receptionist);
                    }
                    break;
                default:
                    notificationService.ShowError("Invalid choice. Please select 1 or 2.");
                    break;
            }

            logger.LogActivity("Authentication", "Failed", "Invalid credentials provided");
            return (false, UserRole.Admin);
        }

        private bool AuthenticateAdmin()
        {
            Console.WriteLine("\n=== ADMINISTRATOR LOGIN ===");
            Console.WriteLine("Default credentials: admin / admin123");
            Console.Write("Enter admin username: ");
            string username = Console.ReadLine() ?? "";
            
            Console.Write("Enter admin password: ");
            string password = Console.ReadLine() ?? "";

            if (username.Equals("admin", StringComparison.OrdinalIgnoreCase) && password == "admin123")
            {
                notificationService.ShowSuccess("Admin authentication successful!");
                return true;
            }

            notificationService.ShowError("Invalid admin credentials. Please try again.");
            return false;
        }

        private bool AuthenticateReceptionist()
        {
            Console.WriteLine("\n=== RECEPTIONIST LOGIN ===");
            Console.WriteLine("Default credentials: receptionist / rec123");
            Console.Write("Enter receptionist username: ");
            string username = Console.ReadLine() ?? "";
            
            Console.Write("Enter receptionist password: ");
            string password = Console.ReadLine() ?? "";

            if (username.Equals("receptionist", StringComparison.OrdinalIgnoreCase) && password == "rec123")
            {
                notificationService.ShowSuccess("Receptionist authentication successful!");
                return true;
            }

            notificationService.ShowError("Invalid receptionist credentials. Please try again.");
            return false;
        }

        private string ReadPassword()
        {
            return Console.ReadLine() ?? "";
        }
    }
}
