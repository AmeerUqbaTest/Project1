using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    public interface IVisit
    {
        int VisitId { get; set; }
        string PatientName { get; set; }
        DateTime VisitDate { get; set; }
        string VisitType { get; }
        string Description { get; set; }
        string DoctorName { get; set; }
        int DurationInMinutes { get; set; }
        decimal Fee { get; }
        
        decimal CalculateFee();
        bool ValidateVisit();
        string GetVisitSummary();
        Dictionary<string, object> ToData();
    }
}
