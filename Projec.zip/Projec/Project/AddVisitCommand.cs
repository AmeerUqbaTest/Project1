namespace ConsoleApp1
{
    public class AddVisitCommand : ICommand
    {
        private readonly IVisitRepository repository;
        private readonly IVisit visit;

        public AddVisitCommand(IVisitRepository repository, IVisit visit)
        {
            this.repository = repository;
            this.visit = visit;
        }

        public void Execute()
        {
            repository.AddVisit(visit);
        }

        public void Undo()
        {
            repository.DeleteVisit(visit.VisitId);
        }
    }
}
