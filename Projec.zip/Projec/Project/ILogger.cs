using System;

namespace ConsoleApp1
{
    public interface ILogger
    {
        void LogActivity(string action, string outcome, string details = "");
        void LogError(string message, Exception? exception = null);
        void LogInfo(string message);
    }
}
