using System.Collections.Generic;

namespace ConsoleApp1
{
    public interface IReportService
    {
        void GenerateIndividualVisitSummary(int visitId);
        void GenerateVisitCountByType();
        void GenerateWeeklyVisitSummary(System.DateTime weekStart);
        void GenerateMonthlyStatistics(int month, int year);
        void GenerateRevenueReport();
    }
}
