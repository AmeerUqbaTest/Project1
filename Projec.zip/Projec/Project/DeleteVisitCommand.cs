namespace ConsoleApp1
{
    public class DeleteVisitCommand : ICommand
    {
        private readonly IVisitRepository repository;
        private readonly IVisit visit;

        public DeleteVisitCommand(IVisitRepository repository, IVisit visit)
        {
            this.repository = repository;
            this.visit = visit;
        }

        public void Execute()
        {
            repository.DeleteVisit(visit.VisitId);
        }

        public void Undo()
        {
            repository.AddVisit(visit);
        }
    }
}
