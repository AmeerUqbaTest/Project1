using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
    public class ConflictDetectionService
    {
        public bool HasTimeSlotConflict(List<Patient> existingPatients, string patientName, DateTime visitDateTime)
        {
            TimeSpan conflictWindow = TimeSpan.FromMinutes(30);
            
            foreach (Patient existingPatient in existingPatients)
            {
                if (existingPatient.patientName.Equals(patientName, StringComparison.OrdinalIgnoreCase))
                {
                    TimeSpan timeDifference = Math.Abs((existingPatient.visitDate - visitDateTime).TotalMinutes) < conflictWindow.TotalMinutes 
                        ? TimeSpan.FromMinutes(Math.Abs((existingPatient.visitDate - visitDateTime).TotalMinutes))
                        : TimeSpan.MaxValue;
                    
                    if (timeDifference.TotalMinutes <= conflictWindow.TotalMinutes)
                    {
                        return true;
                    }
                }
            }
            
            return false;
        }

        public bool RequestConflictOverride()
        {
            Console.WriteLine();
            Console.WriteLine("*** WARNING: This patient has another visit within 30 minutes. ***");
            Console.Write("Do you want to proceed anyway? (Y/N): ");
            string response = Console.ReadLine()?.ToUpper() ?? "";
            return response == "Y" || response == "YES";
        }
    }
}
