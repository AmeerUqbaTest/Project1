using System;
using System.Collections.Generic;
using System.IO;

namespace ConsoleApp1
{
    public class AuthenticationService
    {
        private Dictionary<string, (string password, UserRole role)> credentials;

        public AuthenticationService()
        {
            credentials = new Dictionary<string, (string, UserRole)>
            {
                { "admin", ("admin123", UserRole.Admin) },
                { "receptionist", ("recep123", UserRole.Receptionist) }
            };
        }

        public (bool isAuthenticated, UserRole role) Authenticate()
        {
            Console.WriteLine("=== LOGIN ===");
            Console.Write("Enter username: ");
            string username = Console.ReadLine()?.ToLower() ?? "";
            
            Console.Write("Enter password: ");
            string password = Console.ReadLine() ?? "";

            if (!string.IsNullOrEmpty(username) && credentials.ContainsKey(username) && credentials[username].password == password)
            {
                Console.WriteLine($"Login successful! Welcome {username}.");
                return (true, credentials[username].role);
            }

            Console.WriteLine("Invalid credentials!");
            return (false, UserRole.Receptionist);
        }
    }
}
