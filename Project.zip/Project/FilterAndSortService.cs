using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
    public class FilterAndSortService
    {
        public List<Patient> FilterPatients(List<Patient> patients, string filterType, string filterValue)
        {
            return filterType.ToLower() switch
            {
                "doctor" => patients.Where(p => p.doctorName.Contains(filterValue, StringComparison.OrdinalIgnoreCase)).ToList(),
                "type" => patients.Where(p => p.visitType.Contains(filterValue, StringComparison.OrdinalIgnoreCase)).ToList(),
                "name" => patients.Where(p => p.patientName.Contains(filterValue, StringComparison.OrdinalIgnoreCase)).ToList(),
                _ => patients
            };
        }

        public List<Patient> FilterByDateRange(List<Patient> patients, DateTime startDate, DateTime endDate)
        {
            return patients.Where(p => p.visitDate.Date >= startDate.Date && p.visitDate.Date <= endDate.Date).ToList();
        }

        public List<Patient> SortPatients(List<Patient> patients, string sortBy)
        {
            return sortBy.ToLower() switch
            {
                "name" => patients.OrderBy(p => p.patientName).ToList(),
                "date" => patients.OrderBy(p => p.visitDate).ToList(),
                "type" => patients.OrderBy(p => p.visitType).ToList(),
                "doctor" => patients.OrderBy(p => p.doctorName).ToList(),
                _ => patients.OrderBy(p => p.visitDate).ToList()
            };
        }

        public void ShowFilterAndSortMenu(List<Patient> patients, Action<List<Patient>> displayResults)
        {
            Console.WriteLine("=== FILTER AND SORT OPTIONS ===");
            Console.WriteLine("1. Filter by Doctor Name");
            Console.WriteLine("2. Filter by Visit Type");
            Console.WriteLine("3. Filter by Patient Name");
            Console.WriteLine("4. Filter by Date Range");
            Console.WriteLine("5. Sort Results");
            Console.WriteLine("6. Show All (No Filter)");
            Console.Write("Choose option (1-6): ");

            string choice = Console.ReadLine() ?? "";
            List<Patient> filteredPatients = new List<Patient>(patients);

            switch (choice)
            {
                case "1":
                    Console.Write("Enter doctor name (partial match): ");
                    string doctorFilter = Console.ReadLine() ?? "";
                    filteredPatients = FilterPatients(patients, "doctor", doctorFilter);
                    break;
                case "2":
                    Console.WriteLine("Select visit type:");
                    Console.WriteLine("1. Consultation");
                    Console.WriteLine("2. Follow-up");
                    Console.WriteLine("3. Emergency");
                    Console.WriteLine("4. Routine Check-up");
                    Console.Write("Enter choice (1-4): ");
                    string typeChoice = Console.ReadLine() ?? "";
                    string visitType = typeChoice switch
                    {
                        "1" => "Consultation",
                        "2" => "Follow-up",
                        "3" => "Emergency",
                        "4" => "Routine Check-up",
                        _ => ""
                    };
                    filteredPatients = FilterPatients(patients, "type", visitType);
                    break;
                case "3":
                    Console.Write("Enter patient name (partial match): ");
                    string nameFilter = Console.ReadLine() ?? "";
                    filteredPatients = FilterPatients(patients, "name", nameFilter);
                    break;
                case "4":
                    Console.Write("Enter start date (DD/MM/YYYY): ");
                    string startDateInput = Console.ReadLine() ?? "";
                    if (DateTime.TryParseExact(startDateInput, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime startDate))
                    {
                        Console.Write("Enter end date (DD/MM/YYYY): ");
                        string endDateInput = Console.ReadLine() ?? "";
                        if (DateTime.TryParseExact(endDateInput, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime endDate))
                        {
                            filteredPatients = FilterByDateRange(patients, startDate, endDate);
                        }
                    }
                    break;
                case "5":
                    ShowSortMenu(patients, displayResults);
                    return;
                case "6":
                    filteredPatients = patients;
                    break;
                default:
                    Console.WriteLine("Invalid choice!");
                    return;
            }

            if (choice != "5")
            {
                ShowSortMenu(filteredPatients, displayResults);
            }
        }

        private void ShowSortMenu(List<Patient> patients, Action<List<Patient>> displayResults)
        {
            Console.WriteLine("\n=== SORT OPTIONS ===");
            Console.WriteLine("1. Sort by Patient Name");
            Console.WriteLine("2. Sort by Visit Date");
            Console.WriteLine("3. Sort by Visit Type");
            Console.WriteLine("4. Sort by Doctor Name");
            Console.Write("Choose sort option (1-4): ");

            string sortChoice = Console.ReadLine() ?? "";
            string sortBy = sortChoice switch
            {
                "1" => "name",
                "2" => "date",
                "3" => "type",
                "4" => "doctor",
                _ => "date"
            };

            List<Patient> sortedPatients = SortPatients(patients, sortBy);
            displayResults(sortedPatients);
        }
    }
}
